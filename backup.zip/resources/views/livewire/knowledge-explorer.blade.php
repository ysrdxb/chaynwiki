@php
    $genreNodeCount = count($genreNetwork['nodes'] ?? []);
    $genreEdgeCount = count($genreNetwork['edges'] ?? []);
    $artistNodeCount = count($artistNetwork['nodes'] ?? []);
    $artistEdgeCount = count($artistNetwork['edges'] ?? []);
    $timelineCount = count($timeline ?? []);
@endphp

<div class="min-h-screen bg-primary pt-32" x-data="{ loaded: false }" x-init="setTimeout(() => loaded = true, 800)">
    {{-- Header --}}
    <div class="relative py-16 border-b border-white/5 overflow-hidden section-divider">
        <div class="absolute inset-0 bg-gradient-to-b from-[#38bdf8]/10 via-transparent to-transparent"></div>
        <div class="absolute inset-0 opacity-20" style="background: radial-gradient(circle at 15% 20%, rgba(59,130,246,0.12), transparent 40%), radial-gradient(circle at 85% 30%, rgba(139,92,246,0.12), transparent 45%);"></div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center mb-10">
                <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#38bdf8]/5 border border-[#38bdf8]/10 text-[#38bdf8] text-[9px] font-black uppercase tracking-[0.2em] mb-6">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
                    </svg>
                    Interactive Explorer Node
                </div>
                <h1 class="text-4xl md:text-6xl font-black text-white italic uppercase tracking-tighter mb-4 leading-none">
                    KNOWLEDGE <span class="text-[#38bdf8]">EXPLORER</span>
                </h1>
                <p class="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] max-w-xl mx-auto leading-relaxed">
                    Map the evolution of genres, track artist collaborations, and navigate the global music archive.
                </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
                <div class="bg-secondary/60 border border-white/5 rounded-2xl p-4 text-center">
                    <div class="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Genres</div>
                    <div class="text-2xl font-black text-white mt-2">{{ number_format($genreNodeCount) }}</div>
                    <div class="text-[10px] text-white/30">{{ number_format($genreEdgeCount) }} links</div>
                </div>
                <div class="bg-secondary/60 border border-white/5 rounded-2xl p-4 text-center">
                    <div class="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Artists</div>
                    <div class="text-2xl font-black text-white mt-2">{{ number_format($artistNodeCount) }}</div>
                    <div class="text-[10px] text-white/30">{{ number_format($artistEdgeCount) }} links</div>
                </div>
                <div class="bg-secondary/60 border border-white/5 rounded-2xl p-4 text-center">
                    <div class="text-[10px] font-black text-white/30 uppercase tracking-[0.2em]">Timeline</div>
                    <div class="text-2xl font-black text-white mt-2">{{ number_format($timelineCount) }}</div>
                    <div class="text-[10px] text-white/30">milestones</div>
                </div>
            </div>

            {{-- Tab Navigation --}}
            <div class="flex justify-center gap-4">
                @foreach(['genres' => 'Genre Map', 'artists' => 'Artist Network', 'timeline' => 'Chronology'] as $tab => $label)
                <button
                    wire:click="setTab('{{ $tab }}')"
                    class="px-6 py-2.5 rounded-xl font-black text-[9px] uppercase tracking-[0.2em] transition-all {{ $activeTab === $tab ? 'bg-[#38bdf8] text-[#0a0e14] shadow-xl shadow-[#38bdf8]/10' : 'bg-white/5 text-white/20 border border-white/5 hover:border-white/10 hover:text-white' }}"
                >
                    <span class="flex items-center gap-2">
                        @if($tab === 'genres')
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        @elseif($tab === 'artists')
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                        @else
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        @endif
                        {{ $label }}
                    </span>
                </button>
                @endforeach
            </div>
        </div>
    </div>

    {{-- Skeleton Loader --}}
    <div x-show="!loaded" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 transition-all duration-500">
        <div class="flex flex-col lg:flex-row gap-8">
            <div class="flex-1">
                <div class="bg-secondary border border-white/5 rounded-2xl overflow-hidden skeleton-v2" style="height: 600px;"></div>
                <div class="mt-6 flex justify-center gap-4">
                    <div class="w-24 h-2 bg-white/5 rounded-full skeleton-v2"></div>
                    <div class="w-24 h-2 bg-white/5 rounded-full skeleton-v2"></div>
                    <div class="w-24 h-2 bg-white/5 rounded-full skeleton-v2"></div>
                </div>
            </div>
            <div class="w-full lg:w-80 space-y-4">
                <div class="bg-secondary border border-white/5 rounded-2xl p-8 skeleton-v2" style="height: 400px;"></div>
            </div>
        </div>
    </div>

    {{-- Explorer Content --}}
    <div x-show="loaded" x-transition:enter="transition ease-out duration-700 delay-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="flex flex-col lg:flex-row gap-8">
            <div class="flex-1 relative group">
                <div class="bg-secondary border border-white/5 rounded-2xl overflow-hidden shadow-2xl transition-all duration-500 hover:border-[#38bdf8]/10 relative" style="min-height: 640px;">
                    <div wire:loading wire:target="setTab" class="absolute inset-0 bg-black/40 backdrop-blur-sm z-20 flex items-center justify-center rounded-3xl">
                        <div class="flex flex-col items-center gap-3">
                            <div class="w-10 h-10 border-4 border-[#38bdf8]/20 border-t-[#38bdf8] rounded-full animate-spin"></div>
                            <span class="text-xs font-mono text-[#38bdf8] uppercase tracking-widest">Recalculating...</span>
                        </div>
                    </div>
                    <div class="absolute bottom-4 left-4 z-10 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-[10px] text-white/60">
                        Drag to move · Scroll to zoom · Click node to inspect
                    </div>
                    @if($activeTab === 'genres' || $activeTab === 'artists')
                        <div class="absolute top-4 right-4 z-10 flex items-center gap-2 bg-black/40 border border-white/10 rounded-xl p-2">
                            <button type="button" data-explorer-control="zoom-in" class="w-8 h-8 rounded-lg bg-white/5 text-white/60 hover:text-white hover:bg-white/10 transition">+</button>
                            <button type="button" data-explorer-control="zoom-out" class="w-8 h-8 rounded-lg bg-white/5 text-white/60 hover:text-white hover:bg-white/10 transition">-</button>
                            <button type="button" data-explorer-control="fit" class="px-3 h-8 rounded-lg bg-white/5 text-white/60 hover:text-white hover:bg-white/10 text-[10px] font-black uppercase tracking-widest transition">Fit</button>
                        </div>
                    @endif
                    @if($activeTab === 'genres')
                        @if(empty($genreNetwork['nodes']))
                            <div class="h-[600px] flex items-center justify-center text-white/30 text-sm">No genre data yet.</div>
                        @else
                            <div id="genre-network" class="w-full h-[640px]" wire:ignore></div>
                        @endif
                    @elseif($activeTab === 'artists')
                        @if(empty($artistNetwork['nodes']))
                            <div class="h-[600px] flex items-center justify-center text-white/30 text-sm">No artist data yet.</div>
                        @else
                            <div id="artist-network" class="w-full h-[640px]" wire:ignore></div>
                        @endif
                    @elseif($activeTab === 'timeline')
                        @if(empty($timeline))
                            <div class="h-[600px] flex items-center justify-center text-white/30 text-sm">No timeline data yet.</div>
                        @else
                            <div id="music-timeline" class="w-full h-[640px]" wire:ignore></div>
                        @endif
                    @endif
                </div>

                {{-- Legend --}}
                <div class="mt-4 flex flex-wrap gap-4 justify-center text-sm text-gray-400">
                    @if($activeTab === 'genres')
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-green-500"></span>
                            <span>Influences</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-yellow-500"></span>
                            <span>Derived From</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="w-3 h-3 rounded-full bg-[#a78bfa]"></span>
                            <span>Fusion</span>
                        </div>
                    @endif
                </div>
            </div>

            {{-- Side Panel (Genre Details) --}}
            <div class="w-full lg:w-80">
                @if($genreDetails)
                    <div class="bg-secondary border border-white/5 rounded-2xl p-8 sticky top-32 shadow-2xl animate-fade-in">
                        <div class="flex items-center justify-between mb-8">
                            <h3 class="text-xl font-black text-white uppercase italic tracking-tighter">{{ $genreDetails['genre']['name'] ?? 'Node Detail' }}</h3>
                        <button wire:click="closeDetails" class="text-white/20 hover:text-white transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </button>
                    </div>

                    {{-- Influenced By --}}
                    @if(!empty($genreDetails['influenced_by']))
                        <div class="mb-4">
                            <div class="text-xs font-mono uppercase text-gray-500 mb-2">Influenced By</div>
                            <div class="flex flex-wrap gap-2">
                                @foreach($genreDetails['influenced_by'] as $genre)
                                    <span class="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs">{{ $genre['name'] ?? 'Unknown' }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    {{-- Influences --}}
                    @if(!empty($genreDetails['influences']))
                        <div class="mb-4">
                            <div class="text-xs font-mono uppercase text-gray-500 mb-2">Influenced</div>
                            <div class="flex flex-wrap gap-2">
                                @foreach($genreDetails['influences'] as $genre)
                                    <span class="px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded text-xs">{{ $genre['name'] ?? 'Unknown' }}</span>
                                @endforeach
                            </div>
                        </div>
                    @endif

                    {{-- Related Articles --}}
                    @if(!empty($genreDetails['articles']))
                        <div>
                            <div class="text-xs font-mono uppercase text-gray-500 mb-2">Related Articles</div>
                            <div class="space-y-2">
                                @foreach(array_slice($genreDetails['articles'], 0, 5) as $article)
                                    <a href="{{ route('wiki.show', ['article' => $article['slug']]) }}" class="block text-sm text-gray-300 hover:text-[#a78bfa] truncate">
                                        {{ $article['title'] ?? 'Untitled' }}
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    @endif
                @else
                    <div class="bg-secondary/40 border border-white/5 border-dashed rounded-2xl p-8 text-center sticky top-32 h-[410px] flex flex-col items-center justify-center">
                        <div class="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-6">
                            <svg class="w-8 h-8 text-white/10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"/>
                            </svg>
                        </div>
                        <h4 class="text-[11px] font-black text-white uppercase tracking-widest mb-2">Select a Node</h4>
                        <p class="text-[9px] font-black text-white/20 uppercase tracking-widest leading-loose">Interact with the visualization map to access detailed record connections.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Vis.js Script --}}
    @push('styles')
    <link rel="stylesheet" href="https://unpkg.com/vis-timeline/styles/vis-timeline-graph2d.min.css">
    @endpush

    @push('scripts')
    <script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <script src="https://unpkg.com/vis-timeline/standalone/umd/vis-timeline-graph2d.min.js"></script>
    <script>
        document.addEventListener('livewire:navigated', initNetworks);
        document.addEventListener('DOMContentLoaded', initNetworks);
        document.addEventListener('explorer-tab-changed', () => setTimeout(initNetworks, 60));

        function initNetworks() {
            const genreData = @json($genreNetwork);
            const artistData = @json($artistNetwork);
            const timelineData = @json($timeline);

            // Premium Dark Theme Options
            const darkThemeOptions = {
                nodes: {
                    shape: 'dot',
                    font: {
                        color: '#FFFFFF',
                        size: 14,
                        face: 'Plus Jakarta Sans, sans-serif',
                        bold: {
                            color: '#FFFFFF',
                            size: 16
                        }
                    },
                    borderWidth: 2,
                    borderWidthSelected: 3,
                    shadow: {
                        enabled: true,
                        color: 'rgba(59, 130, 246, 0.3)',
                        size: 10,
                        x: 0,
                        y: 0
                    }
                },
                edges: {
                    smooth: {
                        type: 'continuous',
                        roundness: 0.5
                    },
                    font: {
                        color: '#9CA3AF',
                        size: 11,
                        face: 'Plus Jakarta Sans, sans-serif',
                        align: 'middle',
                        strokeWidth: 0
                    },
                    width: 2,
                    selectionWidth: 3,
                    shadow: {
                        enabled: true,
                        color: 'rgba(0, 0, 0, 0.2)',
                        size: 5
                    }
                },
                physics: {
                    enabled: true,
                    stabilization: {
                        enabled: true,
                        iterations: 250,
                        updateInterval: 25
                    },
                    barnesHut: {
                        gravitationalConstant: -5200,
                        centralGravity: 0.25,
                        springLength: 110,
                        springConstant: 0.05,
                        damping: 0.08,
                        avoidOverlap: 0.2
                    }
                },
                interaction: {
                    hover: true,
                    tooltipDelay: 100,
                    hideEdgesOnDrag: false,
                    hideEdgesOnZoom: false,
                    zoomView: true
                },
                layout: {
                    improvedLayout: true,
                    randomSeed: 42
                }
            };

            // Genre Network
            const genreContainer = document.getElementById('genre-network');
            window.explorerNetworks = window.explorerNetworks || {};
            window.explorerTimelines = window.explorerTimelines || {};

            if (window.explorerNetworks.genre) {
                window.explorerNetworks.genre.destroy();
                window.explorerNetworks.genre = null;
            }
            if (window.explorerNetworks.artist) {
                window.explorerNetworks.artist.destroy();
                window.explorerNetworks.artist = null;
            }
            if (window.explorerTimelines.timeline) {
                window.explorerTimelines.timeline.destroy();
                window.explorerTimelines.timeline = null;
            }

            if (genreContainer && genreData.nodes.length > 0) {
                const genreNetwork = new vis.Network(genreContainer, {
                    nodes: new vis.DataSet(genreData.nodes),
                    edges: new vis.DataSet(genreData.edges)
                }, darkThemeOptions);
                window.explorerNetworks.genre = genreNetwork;

                genreNetwork.on('click', function(params) {
                    if (params.nodes.length > 0) {
                        @this.selectGenre(params.nodes[0]);
                    }
                });

                // Smooth zoom on hover
                genreNetwork.on('hoverNode', function(params) {
                    genreContainer.style.cursor = 'pointer';
                });

                genreNetwork.on('blurNode', function(params) {
                    genreContainer.style.cursor = 'default';
                });

                const fitGenre = () => {
                    genreNetwork.redraw();
                    genreNetwork.fit({
                        animation: { duration: 500, easingFunction: 'easeInOutQuad' },
                        padding: 110
                    });
                };

                genreNetwork.once('stabilizationIterationsDone', fitGenre);
                setTimeout(fitGenre, 150);
            }

            // Artist Network
            const artistContainer = document.getElementById('artist-network');
            if (artistContainer && artistData.nodes.length > 0) {
                const artistNetwork = new vis.Network(artistContainer, {
                    nodes: new vis.DataSet(artistData.nodes),
                    edges: new vis.DataSet(artistData.edges)
                }, {
                    ...darkThemeOptions,
                    physics: {
                        ...darkThemeOptions.physics,
                        stabilization: { iterations: 280 }
                    }
                });
                window.explorerNetworks.artist = artistNetwork;

                artistNetwork.on('hoverNode', function(params) {
                    artistContainer.style.cursor = 'pointer';
                });

                artistNetwork.on('blurNode', function(params) {
                    artistContainer.style.cursor = 'default';
                });

                const fitArtist = () => {
                    artistNetwork.redraw();
                    artistNetwork.fit({
                        animation: { duration: 500, easingFunction: 'easeInOutQuad' },
                        padding: 110
                    });
                };

                artistNetwork.once('stabilizationIterationsDone', fitArtist);
                setTimeout(fitArtist, 150);
            }

            // Timeline
            const timelineContainer = document.getElementById('music-timeline');
            if (timelineContainer && timelineData.length > 0) {
                const items = timelineData.map(item => ({
                    ...item,
                    group: 1
                }));

                const timeline = new vis.Timeline(timelineContainer, new vis.DataSet(items), {
                    style: 'box',
                    zoomMin: 1000 * 60 * 60 * 24 * 365, // One year
                    margin: { item: 10 },
                    orientation: 'top',
                    showCurrentTime: false,
                    template: function(item) {
                        return `<div style="color: #fff; font-weight: 600;">${item.content}</div>`;
                    }
                });
                window.explorerTimelines.timeline = timeline;
            }
        }

        document.addEventListener('click', function(event) {
            const control = event.target.closest('[data-explorer-control]');
            if (!control) return;
            const action = control.getAttribute('data-explorer-control');
            const isArtist = document.getElementById('artist-network');
            const network = isArtist ? window.explorerNetworks?.artist : window.explorerNetworks?.genre;
            if (!network) return;

            if (action === 'zoom-in') {
                network.moveTo({ scale: network.getScale() * 1.2 });
            }
            if (action === 'zoom-out') {
                network.moveTo({ scale: network.getScale() * 0.85 });
            }
            if (action === 'fit') {
                network.fit({ animation: { duration: 400, easingFunction: 'easeInOutQuad' }, padding: 100 });
            }
        });

        if (window.Livewire && Livewire.hook) {
            Livewire.hook('message.processed', () => {
                initNetworks();
            });
        }
    </script>
    @endpush
</div>
