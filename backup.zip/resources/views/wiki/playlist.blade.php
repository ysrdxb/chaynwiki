@extends('layouts.wiki')

@section('title', $article->title . ' - Curated Playlist - ChaynWiki')

@php
    $seoDescription = $summary ?? Str::limit(strip_tags((string) $article->content), 160);
    $seoImage = $article->featured_image;
    if ($seoImage && !Str::startsWith($seoImage, ['http://', 'https://'])) {
        $seoImage = Storage::url($seoImage);
    }
    $seoImage = $seoImage ?: asset('images/hero_background.png');
@endphp

@section('meta_description', $seoDescription)
@section('meta_image', $seoImage)
@section('canonical', route('wiki.show', $article->slug))
@section('og_type', 'article')

@section('content')
    @php
        $placeholder = 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?auto=format&fit=crop&q=80&w=1200';
        $featured_image = $article->featured_image;
        if ($featured_image && !Str::startsWith($featured_image, ['http://', 'https://'])) {
            $featured_image = Storage::url($featured_image);
        }
        $featured_image = $featured_image ?: $placeholder;

        $playlist = $article->playlist;
        $spotify_id = null;
        if ($playlist?->spotify_id) {
            $spotify_id = $playlist->spotify_id;
        } elseif (!empty($playlist?->platform_link) && Str::contains($playlist->platform_link, 'spotify.com')) {
            $parts = explode('playlist/', $playlist->platform_link);
            if (count($parts) > 1) {
                $spotify_id = explode('?', $parts[1])[0];
            }
        }
    @endphp

    <div x-data="{ loaded: false }" x-init="setTimeout(() => loaded = true, 500)">
        <!-- Actual Content -->
        <div x-show="loaded" x-transition:enter="transition duration-500">
            <!-- HERO SECTION -->
            <div class="relative pt-32 pb-20 bg-primary section-divider overflow-hidden">
                <div class="absolute inset-0 z-0">
                    <img src="{{ $featured_image }}" onerror="this.onerror=null;this.src='{{ $placeholder }}';" class="w-full h-full object-cover grayscale opacity-10 blur-2xl scale-125">
                    <div class="absolute inset-0 bg-gradient-to-t from-primary via-primary/60 to-transparent"></div>
                </div>
                
                <div class="relative z-10 max-w-[1200px] mx-auto px-8">
                    <div class="flex flex-col lg:flex-row gap-12 items-center">
                        <div class="lg:w-80 flex-shrink-0">
                            <div class="aspect-square rounded-3xl overflow-hidden border border-white/10 shadow-3xl relative group">
                                <img src="{{ $featured_image }}" onerror="this.onerror=null;this.src='{{ $placeholder }}';" class="w-full h-full object-cover group-hover:scale-110 transition duration-1000">
                                <div class="absolute inset-0 bg-[#38bdf8]/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                    <svg class="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                </div>
                            </div>
                        </div>

                        <div class="flex-1 text-center lg:text-left">
                            <nav class="flex items-center justify-center lg:justify-start gap-2 text-[9px] font-black text-white/20 uppercase tracking-[0.2em] mb-8">
                                <a href="{{ route('home') }}" class="hover:text-[#38bdf8]">Home</a>
                                <span>/</span>
                                <a href="{{ route('wiki.index', ['category' => 'playlist']) }}" class="hover:text-[#38bdf8]">Playlists</a>
                                <span>/</span>
                                <span class="text-[#38bdf8]">Curated Archive</span>
                            </nav>

                            <h1 class="text-5xl lg:text-8xl font-black text-white italic uppercase tracking-tighter mb-8 leading-none">
                                {{ $article->title }}
                            </h1>

                            <div class="flex flex-wrap items-center justify-center lg:justify-start gap-8">
                                <div class="flex flex-col">
                                    <span class="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Track Count</span>
                                    <span class="text-2xl font-black text-white italic">{{ $playlist->track_count ?? '0' }} SONGS</span>
                                </div>
                                <div class="w-px h-10 bg-white/5"></div>
                                <div class="flex flex-col">
                                    <span class="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Total Impact</span>
                                    <span class="text-2xl font-black text-white italic">{{ number_format($article->view_count ?? 0) }} STREAMED</span>
                                </div>
                                <div class="w-px h-10 bg-white/5"></div>
                                <div class="flex flex-col">
                                    <span class="text-[10px] font-black text-white/20 uppercase tracking-widest mb-1">Last Updated</span>
                                    <span class="text-2xl font-black text-white italic uppercase">{{ optional($article->updated_at)->format('M Y') ?? 'Unknown' }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CONTENT AREA -->
            <section class="bg-primary section-divider">
                <div class="max-w-[1200px] mx-auto px-8 py-16">
                    <div class="grid lg:grid-cols-3 gap-16">
                    <!-- Sidebar: Curator Info -->
                    <div class="space-y-12">
                        <section>
                            <h3 class="text-xs font-semibold text-[#38bdf8] uppercase tracking-[0.3em] mb-6">Curator Note</h3>
                            <div class="p-8 bg-secondary border border-white/5 rounded-3xl relative overflow-hidden group">
                                <svg class="w-12 h-12 text-white/5 absolute -top-2 -left-2 rotate-12" fill="currentColor" viewBox="0 0 24 24"><path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017V14H17.017C15.9124 14 15.017 13.1046 15.017 12V9C15.017 7.89543 15.9124 7 17.017 7H20.017V10H18.017V12H20.017C21.1216 12 22.017 12.8954 22.017 14V21H14.017ZM3 21V18C3 16.8954 3.89543 16 5 16H8V14H6C4.89543 14 4 13.1046 4 12V9C4 7.89543 4.89543 7 6 7H9V10H7V12H9C10.1046 12 11 12.8954 11 14V21H3Z"/></svg>
                                <p class="text-white/60 text-sm leading-relaxed italic relative z-10">
                                    "{{ $playlist?->curator_note ?: 'This collection represents a specific moment in music history, curated for the ChaynWiki archive.' }}"
                                </p>
                            </div>
                        </section>

                        <section class="space-y-3">
                            <h3 class="text-xs font-semibold text-[#38bdf8] uppercase tracking-[0.3em] mb-4">Transmission Core</h3>
                            <livewire:article.play-button 
                                :articleId="$article->id" 
                                label="Stream Pulse"
                                class="w-full py-3.5 bg-[#38bdf8] text-[#0a0e14] rounded-2xl text-[11px] font-semibold uppercase tracking-[0.2em] hover:scale-[1.02] flex items-center justify-center gap-3 shadow-xl shadow-[#38bdf8]/20"
                            />

                            <x-article.⚡add-to-crate :article="$article" />

                            <div class="flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 rounded-2xl">
                                <span class="text-[10px] font-semibold text-white/50 uppercase tracking-widest">Protocol Utility</span>
                                 <livewire:article.vote-button :model="$article" wire:key="sidebar-vote-article-{{ $article->id }}" />
                            </div>
                        </section>
                    </div>

                    <!-- Main: Article Content & Playlist Embed -->
                    <div class="lg:col-span-2 space-y-16">
                        <article class="prose prose-invert prose-lg max-w-none">
                            <div class="article-content text-white/60 text-sm leading-relaxed">
                                @if(!empty($article->content))
                                    {!! Str::markdown($article->content) !!}
                                @else
                                    <p class="text-white/40">This playlist entry is still being authored. Add a description to complete the archive record.</p>
                                @endif
                            </div>
                        </article>

                        <section>
                            <h3 class="text-lg font-black text-white italic uppercase tracking-tighter mb-8 flex items-center gap-4">
                                <span class="w-10 h-px bg-green-500"></span>
                                Spotify Synchronized
                            </h3>
                            @if($spotify_id)
                                <div class="rounded-3xl overflow-hidden border border-white/5 shadow-2xl bg-black">
                                    <iframe src="https://open.spotify.com/embed/playlist/{{ $spotify_id }}" width="100%" height="450" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                                </div>
                            @else
                                <div class="rounded-3xl border border-white/5 bg-secondary p-10 text-center">
                                    <p class="text-white/50 text-sm">No Spotify link is connected yet for this playlist.</p>
                                    @if(!empty($playlist?->platform_link))
                                        <a href="{{ $playlist->platform_link }}" target="_blank" rel="noopener" class="btn-primary-v2 mt-6">Open Playlist</a>
                                    @endif
                                </div>
                            @endif
                        </section>

                        <section class="pt-16 border-t border-white/5">
                            <livewire:article.comments :article="$article" />
                        </section>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
@endsection
