{{--
    CHAYNWIKI Footer V2 - Ocean Depth Theme
    Premium glassmorphism footer with Ocean Depth colors
--}}

<footer class="relative bg-[#0a0e14]">
    {{-- Gradient Top Border - Ocean Depth --}}
    <div class="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#38bdf8]/25 to-transparent"></div>
    
    {{-- Decorative Glow - Ocean Depth --}}
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[200px] bg-[#38bdf8]/5 blur-[100px] pointer-events-none"></div>
    
    <div class="relative max-w-[1200px] mx-auto px-8 pt-20 pb-16">
        {{-- Main Content --}}
        <div class="flex flex-col items-center">
            {{-- Large Brand Text - Solid White --}}
            <h2 class="text-[40px] sm:text-[56px] md:text-[72px] lg:text-[88px] font-black text-white italic uppercase tracking-[-0.02em] leading-none mb-8 select-none px-4 hover:text-white transition-colors">
                CHAYNWIKI
            </h2>
            
            {{-- Tagline --}}
            <p class="text-[#64748b] text-[10px] font-black uppercase tracking-[0.3em] mb-12 text-center max-w-md">
                Distributed Knowledge Archive Protocol
            </p>
            
            {{-- Social Icons - Unified Ocean Blue hover --}}
            <div class="flex items-center gap-4 mb-10">
                {{-- X (Twitter) --}}
                <a href="https://x.com" class="group w-12 h-12 rounded-xl bg-[#38bdf8]/[0.05] border border-[#38bdf8]/[0.1] flex items-center justify-center text-[#64748b] hover:text-white hover:bg-[#38bdf8]/[0.15] hover:border-[#38bdf8]/[0.3] transition-all duration-300" target="_blank" rel="noopener noreferrer">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                </a>
                {{-- LinkedIn --}}
                <a href="https://www.linkedin.com" class="group w-12 h-12 rounded-xl bg-[#38bdf8]/[0.05] border border-[#38bdf8]/[0.1] flex items-center justify-center text-[#64748b] hover:text-white hover:bg-[#38bdf8]/[0.15] hover:border-[#38bdf8]/[0.3] transition-all duration-300" target="_blank" rel="noopener noreferrer">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                </a>
                {{-- Instagram --}}
                <a href="https://www.instagram.com" class="group w-12 h-12 rounded-xl bg-[#38bdf8]/[0.05] border border-[#38bdf8]/[0.1] flex items-center justify-center text-[#64748b] hover:text-white hover:bg-[#38bdf8]/[0.15] hover:border-[#38bdf8]/[0.3] transition-all duration-300" target="_blank" rel="noopener noreferrer">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                    </svg>
                </a>
                {{-- Discord --}}
                <a href="https://discord.com" class="group w-12 h-12 rounded-xl bg-[#38bdf8]/[0.05] border border-[#38bdf8]/[0.1] flex items-center justify-center text-[#64748b] hover:text-white hover:bg-[#38bdf8]/[0.15] hover:border-[#38bdf8]/[0.3] transition-all duration-300" target="_blank" rel="noopener noreferrer">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.041-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.077.077 0 00-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 00.084.028 19.839 19.839 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                    </svg>
                </a>
            </div>
            
            {{-- Quick Links - Unified Ocean Blue hover --}}
            <div class="flex flex-wrap items-center justify-center gap-8 mb-12">
                <a href="{{ route('wiki.index') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Browse</a>
                <a href="{{ route('wiki.create') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Contribute</a>
                <a href="{{ route('explore') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Library</a>
                <a href="{{ route('guidelines') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Guidelines</a>
                <a href="{{ route('privacy') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Privacy</a>
                <a href="{{ route('legal') }}" class="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em] hover:text-white transition-colors">Legal</a>
            </div>
            
            {{-- Divider - Ocean Depth --}}
            <div class="w-full max-w-sm h-px bg-gradient-to-r from-transparent via-[#38bdf8]/15 to-transparent mb-8"></div>
            
            {{-- Copyright --}}
            <p class="text-[9px] font-black text-[#64748b] uppercase tracking-[0.4em]">
                © {{ date('Y') }} CHAYN.CORE - SECURED NODE
            </p>
        </div>
    </div>
</footer>
